DESLOT — Third-party licence notices

Credits.txt identifies credited technology, content and reference data.
The adjacent files reproduce the applicable vendor licence notices.
Unreal-Third-Party-Licences.zip preserves the associated Unreal installation's
third-party licence inventory. Individual terms apply to their respective
components; the archive is an inventory, not a claim that every component ships.

PCG Extended Toolkit: https://github.com/PCGEx/PCGExtendedToolkit
Eigen source: https://gitlab.com/libeigen/eigen
OpenSSL source: https://github.com/openssl/openssl
Reference circuit data: https://github.com/bacinger/f1-circuits

Current credits: https://www.superegosoft.com/deslot/legal